package dao.custom;

import dao.CrudDAO;
import entity.OrderDetail;

public interface ItemDetailDAO extends CrudDAO<OrderDetail,String> {

}
